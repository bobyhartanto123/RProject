library(stringr)
library(dplyr)
library(mapboxapi)
library(leaflet)
library(readxl)
library(sf)
library(writexl)
files <- list.files("D:/Fastwork/Jalan Semarang/Jalan Semarang/Excel", full.names = TRUE)
# Membuat sebuah list untuk menyimpan data dari setiap file
all_data <- list()

# Loop melalui setiap file dan membacanya ke dalam list
for (file in files) {
  # Membaca file
  data <- readxl::read_excel(file)
  
  # Menambahkan data ke dalam list all_data
  all_data[[file]] <- data
}

# dataframe kosong
merged_data <- data.frame()

print(length(all_data))

# Loop melalui 24 file pertama dan gabungkan kolom-kolom tertentu dari setiap file
for (i in 1:min(24, length(all_data))) {
  # Membaca data dari file ke-i
  data_i <- all_data[[i]]
  
  # Memilih kolom tertentu dari file ke-i
  if (i == 1) {
    selected_cols <- data_i[, c(2)]
  }else{
    selected_cols <- data_i[, c(2)]
  }
  
  # Gabungkan kolom-kolom dari file ke-i dengan dataframe yang sudah ada
  if (i == 1) {
    merged_data <- selected_cols
    names(merged_data)[ncol(merged_data)] <- paste("time-" ,i, sep = "")
  } else {
    merged_data <- cbind(merged_data, selected_cols)
    
    # Ubah nama kolom menjadi "Time_i"
    names(merged_data)[ncol(merged_data)] <- paste("time_" ,i, sep = "")
  }
}
print(length(all_data))
head(merged_data)

# Jumlah baris
nrow(merged_data)

# Membaca Files mb_direction

# Mengambil daftar semua file dalam folder
files <- list.files("D:/Fastwork/Jalan Semarang/Jalan Semarang/R Data", full.names = TRUE)

# Membuat list untuk menyimpan data dari setiap file RData
route <- list()

# Loop melalui setiap file dan membacanya ke dalam list
for (file in files) {
  # Memuat data dari file RData
  load(file)
  
  # Menambahkan data ke dalam list all_data
  route[[basename(file)]] <- route_list
}

# Rute
## Code

# Syntax Map
syntax_map_rute <- function(dt_route){
  # leaflet map
  peta <- leaflet() %>%
    addMapboxTiles(style_id = "light-v9",
                   username = "mapbox")
  
  # Loop Map
  for (i in 1:length(dt_route)) {
    peta <- peta %>%
      addPolylines(data = dt_route[[i]], 
                   color = "blue",
                   opacity = 1,
                   weight = 1.75,
                   popup = paste("Rute", i)) 
  }
  # Hasil
  peta
}
# Poligon yang digunakan
dt_route <- route[[1]]
syntax_map_rute(dt_route)

# Jumlah Jalan
length(dt_route)

# Rata-rata waktu per jalan
rataan_waktu_per_jalan <- rowMeans(merged_data)

# data frame kosong
merged_color <- data.frame()

# Warna 
for (i in 1:length(dt_route) ) {
  for (j in 1:min(24, length(all_data))){
    if (merged_data[i,j] > rataan_waktu_per_jalan[i]) {
      merged_color[i,j] <- "red"
    }else{
      merged_color[i,j] <- "blue"
    }
    
  }
}

# Hasil
head(merged_color)
# Map Syntax
map_lalu_lintas <- function(j){
  
  # Membuat peta leaflet
  peta <- leaflet() %>%
    addMapboxTiles(style_id = "light-v9",
                   username = "mapbox")
  
  # Menambahkan polyline untuk setiap rute dengan warna sesuai kondisi lalu lintas
  for (i in 1:length(dt_route)) {
    peta <- peta %>%
      addPolylines(data = dt_route[[i]], 
                   color = merged_color[i,j],
                   opacity = 1,
                   weight = 1.75,
                   popup = paste("Rute", i)) 
  }
  
  # Menambahkan legenda untuk peta
  peta <- peta %>%
    addLegend(position = "bottomright",
              colors = c("red", "blue"),  
              labels = c("Macet", "Normal"), 
              title = "Kondisi Lalu Lintas", 
              opacity = 1)
  
  # Mengembalikan peta yang sudah berisi legenda
  return(peta)
}
## Waktu ke-1

# Tampilkan waktu
file_name <- names(all_data)[1]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")



# Map Waktu ke-1
map_lalu_lintas(1)
## Waktu ke-2


# Tampilkan waktu
file_name <- names(all_data)[2]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")


# Map Waktu ke-2
map_lalu_lintas(2)


## Waktu ke-3

# Tampilkan waktu
file_name <- names(all_data)[3]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-3
map_lalu_lintas(3)


## Waktu ke-4

# Tampilkan waktu
file_name <- names(all_data)[4]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")


# Map Waktu ke-4
map_lalu_lintas(4)


## Waktu ke-5

# Tampilkan waktu
file_name <- names(all_data)[5]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-5
map_lalu_lintas(5)

## Waktu ke-6

# Tampilkan waktu
file_name <- names(all_data)[6]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-6
map_lalu_lintas(6)


## Waktu ke-7

# Tampilkan waktu
file_name <- names(all_data)[7]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-7
map_lalu_lintas(7)


## Waktu ke-8

# Tampilkan waktu
file_name <- names(all_data)[8]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-8
map_lalu_lintas(8)

## Waktu ke-9

# Tampilkan waktu
file_name <- names(all_data)[9]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-9
map_lalu_lintas(9)

## Waktu ke-10

# Tampilkan waktu
file_name <- names(all_data)[10]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-10
map_lalu_lintas(10)

## Waktu ke-11

# Tampilkan waktu
file_name <- names(all_data)[11]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-11
map_lalu_lintas(11)


## Waktu ke-12

# Tampilkan waktu
file_name <- names(all_data)[12]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-12
map_lalu_lintas(12)


## Waktu ke-13

# Tampilkan waktu
file_name <- names(all_data)[13]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-13
map_lalu_lintas(13)


## Waktu ke-14

# Tampilkan waktu
file_name <- names(all_data)[14]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-14
map_lalu_lintas(14)


## Waktu ke-15

# Tampilkan waktu
file_name <- names(all_data)[15]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-15
map_lalu_lintas(15)

## Waktu ke-16

# Tampilkan waktu
file_name <- names(all_data)[16]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")


# Map Waktu ke-16
map_lalu_lintas(16)


## Waktu ke-17

# Tampilkan waktu
file_name <- names(all_data)[17]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-17
map_lalu_lintas(17)


## Waktu ke-18

# Tampilkan waktu
file_name <- names(all_data)[18]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")


# Map Waktu ke-18
map_lalu_lintas(18)


## Waktu ke-19

# Tampilkan waktu
file_name <- names(all_data)[19]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-19
map_lalu_lintas(19)


## Waktu ke-20

# Tampilkan waktu
file_name <- names(all_data)[20]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-20
map_lalu_lintas(20)


## Waktu ke-21

# Tampilkan waktu
file_name <- names(all_data)[21]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")

# Map Waktu ke-21
map_lalu_lintas(21)

## Waktu ke-22

# Tampilkan waktu
file_name <- names(all_data)[22]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")


# Map Waktu ke-22
map_lalu_lintas(22)

## Waktu ke-23

# Tampilkan waktu
file_name <- names(all_data)[23]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")


# Map Waktu ke-23
map_lalu_lintas(23)

## Waktu ke-24

# Tampilkan waktu
file_name <- names(all_data)[24]

str_extract(file_name, "\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}")


# Map Waktu ke-24
map_lalu_lintas(24)