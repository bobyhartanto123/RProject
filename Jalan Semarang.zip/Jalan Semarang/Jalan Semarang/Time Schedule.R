# Library 
library(mapboxapi)
library(leaflet)
library(readxl)
library(sf)
library(writexl)
library(lubridate)

# Data
Jalan_Utama <- read_excel("D:/Fastwork/Jalan Semarang/Jalan Semarang/Jalan Semarang.xlsx")

# Token
my_token <- "pk.eyJ1IjoicHJhYnVkaXJnYW50YXJhIiwiYSI6ImNrcmV5bXhyYTA0OHkzMHA2cmR5YXpybTMifQ.HDUA5JhtUClDL5S-gXPZYA"
mb_access_token(my_token, install = TRUE, overwrite = TRUE)

Sys.getenv("MAPBOX_PUBLIC_TOKEN")

# Origin and Destination DataFrames
origin <- data.frame(long = Jalan_Utama$X_Start, lat = Jalan_Utama$Y_Start)
destination <- data.frame(long = Jalan_Utama$X_End, lat = Jalan_Utama$Y_End)

# Initialize Route List and DataFrame for Time Travel
route_list <- list()
time_travel <- data.frame(
  jalan = Jalan_Utama$NAMA,
  Time = numeric(nrow(origin)),
  Jarak = numeric(nrow(origin)),
  Kecepatan = numeric(nrow(origin)),
  Long = Jalan_Utama$X_Start,
  Lat = Jalan_Utama$Y_Start,
  Tgl = as.POSIXct(character(nrow(origin)), format = "%Y-%m-%d %H:%M:%S")
)

# Retry Mechanism and Error Handling
max_retries <- 3

for (i in 1:nrow(origin)) {
  print(paste("Processing route", i))
  
  retries <- 0
  success <- FALSE
  
  while (retries < max_retries && !success) {
    tryCatch({
      # Fetch Route from Mapbox API
      my_route <- mb_directions(
        origin = origin[i, ],
        destination = destination[i, ],
        profile = "driving-traffic",
        steps = TRUE,
        language = "en",
        alternatives = FALSE
      )
      
      if (!is.null(my_route)) {
        # If the API call is successful, store the results
        time_travel[i, "Time"] <- sum(my_route$duration)
        time_travel[i, "Jarak"] <- sum(my_route$distance)
        time_travel[i, "Tgl"] <- Sys.time()
        route_list[[i]] <- my_route
        success <- TRUE
      }
    }, error = function(e) {
      retries <- retries + 1
      message(paste("Error processing route", i, ":", e$message, "Retrying... (", retries, "/", max_retries, ")"))
    })
  }
  
  if (!success) {
    message(paste("Failed to process route", i, "after", max_retries, "attempts."))
    time_travel[i, c("Time", "Jarak", "Kecepatan")] <- NA
    route_list[[i]] <- NULL
  }
}

# Calculate Speed
time_travel$Kecepatan <- ifelse(time_travel$Time != 0, 
                                time_travel$Jarak / time_travel$Time, 
                                NA)

# Save Results
# Save the travel time data to an Excel file
write_xlsx(time_travel, paste0("D:/Fastwork/Jalan Semarang/Jalan Semarang/Excel/hasil_", format(Sys.time(), "%Y-%m-%d_%H-%M-%S"), ".xlsx"))

# Save the route list to an RData file
save(route_list, file = paste0("D:/Fastwork/Jalan Semarang/Jalan Semarang/R Data/hasilR_", format(Sys.time(), "%Y-%m-%d_%H-%M-%S"), ".RData"))