# Load required libraries
library(rvest)
library(dplyr)

# Function to scrape links from all page
scrape_page_links <- function(page_number) {
  link <- paste0("https://www.lamudi.co.id/east-java/lamongan/house/buy/?page=", page_number)
  
  # Read the page
  pages <- read_html(link)
  
  # Extract property links (appending the correct base URL)
  property_links <- pages %>% 
    html_nodes("a.ListingCell-moreInfo-button-v2_redesign") %>% 
    html_attr("href")
  # Make sure to append the correct base URL
  property_links <- ifelse(startsWith(property_links, "http"), 
                           property_links, 
                           paste0("https://www.lamudi.co.id", property_links))
  
  return(property_links)
}
# Print all the scraped property links
print(all_property_links)

get_facilities <- function(property_link){
  property_page <- read_html(property_link)
  property_facility <- property_page %>% 
    html_nodes("section#listing-amenities .listing-amenities-list-item .listing-amenities-name") %>% 
    html_text(trim=TRUE) %>% paste(collapse = ",")
  # Scrape latitude and longitude
  latitude <- property_page %>% 
    html_node("div.LandmarksPDP-Wrapper") %>% 
    html_attr("data-lat")
  
  longitude <- property_page %>% 
    html_node("div.LandmarksPDP-Wrapper") %>% 
    html_attr("data-lon")
  return(list(facilities = property_facility, latitude = latitude, longitude = longitude))
}
# Scrape links from multiple pages (let's assume the first 10 pages)
all_property_links <- c()  # Initialize an empty vector to store the links
for (page in 1:9) {  # Adjust the number of pages as needed
  page_links <- scrape_page_links(page)
  all_property_links <- c(all_property_links, page_links)
}

# Create a data frame to store links, facilities, latitude, and longitude
property_data <- data.frame(
  link = character(),      # To store property links
  facilities = character(),  # To store facility details
  latitude = character(),   # To store latitude
  longitude = character()   # To store longitude
)

# Loop through each link and scrape facilities
for (link in all_property_links) {
  facilities <- get_facilities(link)
  
  # Append the link and facilities to the dataframe
  #property_data <- rbind(property_data, data.frame(link = link, facilities = facilities,latitude=facilities$latitude, longitude=facilities$longitude, stringsAsFactors = FALSE))
  
  # Append the link and facilities to the dataframe
  property_data <- rbind(property_data, data.frame(link = link, facilities = facilities, stringsAsFactors = FALSE))
}
# Print the resulting dataframe

View(property_data)





