# Load required libraries
library(rvest)
library(dplyr)
library(xml2)
library(stringr)


page_urls<- paste0("https://www.lamudi.co.id/east-java/lamongan/house/buy/?page=", 1:3)
# Function to extract data from a page
extract_data <- function(page_urls) {
  page <- read_html(page_urls)
  
  # Extract text from page
  judul <- page %>% html_nodes("h3.ListingCell-KeyInfo-title") %>% html_text()
  alamat <- page %>% html_nodes(".ListingCell-KeyInfo-address") %>% html_text()
  harga <- page %>% html_nodes(".PriceSection-FirstPrice, .PriceSection-NoPrice") %>% html_text()
  info <- page %>% html_nodes(".KeyInformation_v2") %>% html_text()

  
  # Check lengths
  max_length <- max(length(judul), length(alamat), length(harga), length(info))
  
  # Extend vectors with NAs if needed
  judul <- c(judul, rep(NA, max_length - length(judul)))
  alamat <- c(alamat, rep(NA, max_length - length(alamat)))
  harga <- c(harga, rep(NA, max_length - length(harga)))
  info <- c(info, rep(NA, max_length - length(info)))
  
  # Create data frame
  data <- data.frame(judul, alamat, info, harga, stringsAsFactors = FALSE)
  
  # Get data links
  data_links <- page %>% html_nodes("h3.ListingCell-KeyInfo-title") %>% html_attr("href")
  full_links <- paste0("https://www.lamudi.co.id", data_links) # Complete the URLs
  
  # Function to get location from link
  get_coords_from_page <- function(page_urls) {
    page <- read_html(page_urls)
    
    # Extract all divs with the target class
    divs <- page %>% html_nodes('div.ListingCell-AllInfo.ListingUnit')
    
    # Initialize vectors to store lat and long
    latitudes <- vector()
    longitudes <- vector()
    
    # Loop through each div to extract data-geo-point
    for (div in divs) {
      geo_point_attr <- xml_attr(div, 'data-geo-point')
      
      if (!is.na(geo_point_attr)) {
        coords <- str_remove_all(geo_point_attr, "\\[|\\]") %>%
          str_split(",") %>%
          unlist()
        
        if (length(coords) >= 2) {
          latitudes <- c(latitudes, coords[2])  # Latitude
          longitudes <- c(longitudes, coords[1])  # Longitude
        }
      }
    }
    
    # Combine lat and long into a data frame
    data.frame(lat = latitudes, lng = longitudes, stringsAsFactors = FALSE)
  }
  
  # URLs for the pages to scrape
  page_urls <- paste0("https://www.lamudi.co.id/east-java/lamongan/house/buy/?page=", 1:3)
  
  # Scrape data from all pages
  data_list <- lapply(page_urls, get_coords_from_page)
  
  # Combine data from all pages
  all_coords <- bind_rows(data_list)
  
  # Combine data with coordinates
  data <- cbind(data, all_coords)


  # Clean dataset
  data$judul <- trimws(data$judul)
  data$alamat <- trimws(data$alamat)
  data$alamat <- gsub("[ ]{2}", "", data$alamat)
  data$alamat <- gsub("[\n\n]", " ", data$alamat)
  data$harga <- gsub("[^0-9]", "", data$harga)
  data$info <- trimws(data$info)
  
  
  data$info <- gsub("[ ]{2}", "", data$info)
  data$info <- gsub("[\n\n]", " ", data$info)
  data$info <- gsub("\\bKamar tidur\\b", "Kamar", data$info)
  data$info <- gsub("\\bBangunan\\b", "Luas Bangunan", data$info)
  data$info <- gsub("\\bLahan\\b", "Luas Lahan", data$info)
  # Split the 'info' column into three separate columns
  split_info <- function(info_str) {
    # Extract components using regular expressions
    kamar <- sub(" .*", "", info_str)
    building_area <- sub(".*   (\\d+ m²)   .*", "\\1", info_str)
    land_area <- sub(".*   Luas Bangunan        (\\d+ m²)   .*", "\\1", info_str)
    
    # Return as a named vector
    return(c(Kamar = kamar, Luas_Bangunan = building_area, Luas_Lahan = land_area))
  }
  # Apply the function to the 'info' column and convert to a data frame
  df_split <- do.call(rbind, lapply(data$info, function(x) {
    as.data.frame(t(split_info(x)), stringsAsFactors = FALSE)
  }))
  
  # Bind the split data to the original data frame
  data <- cbind(data, df_split)
  data <- data %>%
    select(judul, alamat, Kamar, Luas_Bangunan, Luas_Lahan, harga, everything())
  
 
  return(data)
}

# Scrape data from all pages

data_list <- lapply(page_urls, extract_data)

# Combine data from all pages
Lamongan_data <- bind_rows(data_list)
Lamongan_data <- Lamongan_data %>% 
  select(-info)

# Overview of final data
View(Lamongan_data)


#SCRAPE LAYER 2
# Function to scrape links from all page
scrape_page_links <- function(page_number) {
  link <- paste0("https://www.lamudi.co.id/east-java/lamongan/house/buy/?page=", page_number)
  
  # Read the page
  pages <- read_html(link)
  
  # Extract property links (appending the correct base URL)
  property_links <- pages %>% 
    html_nodes("a.ListingCell-moreInfo-button-v2_redesign") %>% 
    html_attr("href")
  # Make sure to append the correct base URL
  property_links <- ifelse(startsWith(property_links, "http"), 
                           property_links, 
                           paste0("https://www.lamudi.co.id", property_links))
  
  return(property_links)
}
# Print all the scraped property links
print(all_property_links)

get_facilities <- function(property_link){
  property_page <- read_html(property_link)
  property_facility <- property_page %>% 
    html_nodes("section#listing-amenities .listing-amenities-list-item .listing-amenities-name") %>% 
    html_text(trim=TRUE) %>% paste(collapse = ",")
  # Scrape latitude and longitude
  latitude <- property_page %>% 
    html_node("div.LandmarksPDP-Wrapper") %>% 
    html_attr("data-lat")
  
  longitude <- property_page %>% 
    html_node("div.LandmarksPDP-Wrapper") %>% 
    html_attr("data-lon")
  return(list(facilities = property_facility, latitude = latitude, longitude = longitude))
}
# Scrape links from multiple pages
all_property_links <- c()  # Initialize an empty vector to store the links
for (page in 1:9) {  # Adjust the number of pages as needed
  page_links <- scrape_page_links(page)
  all_property_links <- c(all_property_links, page_links)
}

# Create a data frame to store links, facilities, latitude, and longitude
property_data <- data.frame(
  link = character(),      # To store property links
  facilities = character(),  # To store facility details
  latitude = character(),   # To store latitude
  longitude = character()   # To store longitude
)

# Loop through each link and scrape facilities
for (link in all_property_links) {
  facilities <- get_facilities(link)
  
  # Append the link and facilities to the dataframe
  #property_data <- rbind(property_data, data.frame(link = link, facilities = facilities,latitude=facilities$latitude, longitude=facilities$longitude, stringsAsFactors = FALSE))
  
  # Append the link and facilities to the dataframe
  property_data <- rbind(property_data, data.frame(link = link, facilities = facilities, stringsAsFactors = FALSE))
}
# Print the resulting dataframe

View(property_data)


#COMBINE TWO DATAFRAME
 hasil_akhir <- cbind(Lamongan_data,property_data)
 
 View(hasil_akhir)