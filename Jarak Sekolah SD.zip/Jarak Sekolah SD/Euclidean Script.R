# Load required libraries
library(readxl)  # For reading Excel files
library(dplyr)   # For data manipulation
library(geosphere)  # For calculating distances

# Load datasets
real_estate <- read_excel("D:/Fastwork/Jarak Sekolah SD/Dataset Semarang.xlsx", sheet = "Sheet1")
sekolah_sd <- read_excel("D:/Fastwork/Jarak Sekolah SD/Dataset SD.xlsx", sheet = "Sheet1")

# Rename lat and lng columns to be consistent for both datasets
real_estate <- real_estate %>% rename(lat_real = lat, lng_real = lng)
sekolah_sd <- sekolah_sd %>% rename(lat_sekolah = lat, lng_sekolah = long)

# Function to calculate Euclidean distance
euclidean_distance <- function(lat1, lng1, lat2, lng2) {
  sqrt((lat2 - lat1)^2 + (lng2 - lng1)^2)
}

# Create new  columns for the nearest school's coordinates and distance
real_estate <- real_estate %>%
  rowwise() %>%
  mutate(
    nearest_school_info = list(
      sekolah_sd %>%
        mutate(distance = euclidean_distance(lat_real, lng_real, lat_sekolah, lng_sekolah)) %>%
        arrange(distance) %>%
        slice(1)  # Select the nearest school
    ),
    x_Sd = nearest_school_info$lng_sekolah,  # Longitude of the nearest school
    y_Sd = nearest_school_info$lat_sekolah,  # Latitude of the nearest school
    d_SD = nearest_school_info$distance     # Distance to the nearest school
  ) %>%
  ungroup() %>%
  select(-nearest_school_info)

# Write the updated real estate dataset to a new file
write.csv(real_estate, "D:/Fastwork/Jarak Sekolah SD/Updated_Real_Estate_with_Schools.csv", row.names = FALSE)



